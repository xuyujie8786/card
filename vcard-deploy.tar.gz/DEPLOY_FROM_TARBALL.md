# 📦 使用压缩包部署指南

## 1️⃣ 上传压缩包到服务器

```bash
# 在本地电脑上，上传压缩包到服务器
scp vcard-deploy.tar.gz ubuntu@your-server-ip:/home/ubuntu/
```

或者使用 SFTP 工具（FileZilla、Cyberduck 等）上传 `vcard-deploy.tar.gz` 到服务器的 `/home/ubuntu/` 目录。

---

## 2️⃣ 在服务器上解压并部署

### SSH 登录服务器
```bash
ssh ubuntu@your-server-ip
```

### 解压项目
```bash
cd /home/ubuntu
mkdir -p vcard
tar -xzf vcard-deploy.tar.gz -C vcard
cd vcard
```

### 创建环境变量文件
```bash
cat > .env.production << 'EOF'
# ===== 数据库配置 =====
POSTGRES_USER=vcard_user
POSTGRES_PASSWORD=your_secure_password_here
POSTGRES_DB=vcard_db
DATABASE_URL=postgresql://vcard_user:your_secure_password_here@postgres:5432/vcard_db?schema=public

# ===== Redis 配置 =====
REDIS_PASSWORD=your_redis_password_here
REDIS_URL=redis://:your_redis_password_here@redis:6379

# ===== JWT 密钥 =====
JWT_SECRET=your_jwt_secret_key_here_minimum_32_characters_long

# ===== 应用配置 =====
NODE_ENV=production
PORT=3001

# ===== 前端配置 =====
NEXT_PUBLIC_API_URL=http://your-server-ip:3001

# ===== 邮件配置（可选）=====
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
SMTP_FROM=your-email@gmail.com
EOF
```

### 修改环境变量
```bash
# 使用 nano 或 vim 编辑 .env.production
nano .env.production

# 必须修改以下值：
# 1. POSTGRES_PASSWORD - 设置一个强密码
# 2. REDIS_PASSWORD - 设置一个强密码  
# 3. JWT_SECRET - 设置一个至少32字符的随机字符串
# 4. NEXT_PUBLIC_API_URL - 改为你的服务器IP地址
# 5. DATABASE_URL 中的密码要和 POSTGRES_PASSWORD 一致
# 6. REDIS_URL 中的密码要和 REDIS_PASSWORD 一致
```

### 安装 Docker 和 Docker Compose（如果还没安装）
```bash
# 更新系统
sudo apt update && sudo apt upgrade -y

# 安装 Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# 添加当前用户到 docker 组
sudo usermod -aG docker $USER

# 安装 Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# 重新登录使组权限生效
exit
# 重新 SSH 登录
```

### 启动服务
```bash
cd /home/ubuntu/vcard

# 构建并启动所有服务
docker-compose -f docker-compose.production.yml up -d --build

# 查看启动日志
docker-compose -f docker-compose.production.yml logs -f
```

### 运行数据库迁移
```bash
# 等待数据库完全启动（大约 10-15 秒）
sleep 15

# 运行数据库迁移
docker-compose -f docker-compose.production.yml exec backend npx prisma migrate deploy

# 生成 Prisma Client
docker-compose -f docker-compose.production.yml exec backend npx prisma generate
```

---

## 3️⃣ 验证部署

### 检查服务状态
```bash
# 查看所有容器状态
docker-compose -f docker-compose.production.yml ps

# 应该看到以下容器都是 Up 状态：
# - vcard-frontend
# - vcard-backend  
# - postgres
# - redis
```

### 测试访问
```bash
# 测试后端 API
curl http://localhost:3001/health

# 测试前端（从本地浏览器访问）
# http://your-server-ip:8000
```

### 查看日志
```bash
# 查看所有日志
docker-compose -f docker-compose.production.yml logs -f

# 查看特定服务日志
docker-compose -f docker-compose.production.yml logs -f backend
docker-compose -f docker-compose.production.yml logs -f frontend
```

---

## 4️⃣ 配置防火墙

### 开放必要端口
```bash
# 如果使用 UFW
sudo ufw allow 8000/tcp   # 前端
sudo ufw allow 3001/tcp   # 后端 API
sudo ufw enable

# 如果使用 AWS/Lightsail
# 在控制台的防火墙规则中添加：
# - TCP 8000 (前端)
# - TCP 3001 (后端 API)
```

---

## 5️⃣ 常用管理命令

### 停止服务
```bash
docker-compose -f docker-compose.production.yml down
```

### 重启服务
```bash
docker-compose -f docker-compose.production.yml restart
```

### 更新代码后重新部署
```bash
# 上传新的压缩包
# 然后在服务器上：
cd /home/ubuntu/vcard
docker-compose -f docker-compose.production.yml down
rm -rf *  # 删除旧文件
tar -xzf ../vcard-deploy.tar.gz
docker-compose -f docker-compose.production.yml up -d --build
```

### 备份数据库
```bash
docker-compose -f docker-compose.production.yml exec postgres pg_dump -U vcard_user vcard_db > backup_$(date +%Y%m%d).sql
```

### 查看资源使用
```bash
docker stats
```

---

## ⚠️ 注意事项

1. **密码安全**：
   - 必须修改所有默认密码
   - 使用强密码（至少包含大小写字母、数字、特殊符号）
   - 不要在公开场合分享 `.env.production` 文件

2. **防火墙**：
   - 只开放必要的端口（8000、3001）
   - 不要开放 PostgreSQL（5432）和 Redis（6379）端口

3. **备份**：
   - 定期备份数据库
   - 保存 `.env.production` 文件的副本

4. **监控**：
   - 定期查看日志
   - 监控服务器资源使用情况
   - 设置自动重启（见下方）

---

## 🔄 设置自动重启

创建 systemd 服务以确保 Docker 容器开机自启：

```bash
# 确保 Docker 服务开机自启
sudo systemctl enable docker

# Docker Compose 会自动重启容器（因为 docker-compose.yml 中设置了 restart: unless-stopped）
```

---

## 🆘 故障排查

### 容器无法启动
```bash
# 查看详细日志
docker-compose -f docker-compose.production.yml logs

# 检查端口占用
sudo netstat -tulpn | grep -E ':(8000|3001|5432|6379)'

# 重新构建
docker-compose -f docker-compose.production.yml down -v
docker-compose -f docker-compose.production.yml up -d --build
```

### 数据库连接失败
```bash
# 检查数据库容器
docker-compose -f docker-compose.production.yml exec postgres psql -U vcard_user -d vcard_db

# 检查环境变量
docker-compose -f docker-compose.production.yml exec backend env | grep DATABASE
```

### 前端无法访问后端
```bash
# 检查 NEXT_PUBLIC_API_URL 是否正确
docker-compose -f docker-compose.production.yml exec frontend env | grep NEXT_PUBLIC

# 确保后端健康检查通过
curl http://localhost:3001/health
```

---

## 📞 需要帮助？

如果遇到问题，请提供：
1. 错误日志：`docker-compose -f docker-compose.production.yml logs`
2. 容器状态：`docker-compose -f docker-compose.production.yml ps`
3. 具体的错误信息


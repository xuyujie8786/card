-- CreateEnum
CREATE TYPE "public"."UserRole" AS ENUM ('super_admin', 'admin', 'user');

-- CreateEnum
CREATE TYPE "public"."UserStatus" AS ENUM ('active', 'inactive', 'suspended');

-- CreateEnum
CREATE TYPE "public"."CardStatus" AS ENUM ('active', 'frozen', 'released');

-- CreateEnum
CREATE TYPE "public"."BalanceLogType" AS ENUM ('deposit', 'withdraw', 'transfer_in', 'transfer_out', 'card_charge', 'refund');

-- CreateEnum
CREATE TYPE "public"."TransactionType" AS ENUM ('authorization', 'settlement', 'refund');

-- CreateEnum
CREATE TYPE "public"."TransactionStatus" AS ENUM ('pending', 'completed', 'failed', 'cancelled');

-- CreateTable
CREATE TABLE "public"."users" (
    "id" SERIAL NOT NULL,
    "username" VARCHAR(50) NOT NULL,
    "email" VARCHAR(100) NOT NULL,
    "password_hash" VARCHAR(255) NOT NULL,
    "name" VARCHAR(100),
    "role" "public"."UserRole" NOT NULL DEFAULT 'user',
    "parent_id" INTEGER,
    "status" "public"."UserStatus" NOT NULL DEFAULT 'active',
    "balance" DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    "credit_limit" DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    "currency" VARCHAR(3) NOT NULL DEFAULT 'USD',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."user_balance_logs" (
    "id" SERIAL NOT NULL,
    "user_id" INTEGER NOT NULL,
    "type" "public"."BalanceLogType" NOT NULL,
    "amount" DECIMAL(15,2) NOT NULL,
    "balance_before" DECIMAL(15,2) NOT NULL,
    "balance_after" DECIMAL(15,2) NOT NULL,
    "currency" VARCHAR(3) NOT NULL,
    "related_card_id" INTEGER,
    "related_user_id" INTEGER,
    "description" TEXT,
    "remark" TEXT,
    "operated_by" INTEGER NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "user_balance_logs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."virtual_cards" (
    "id" SERIAL NOT NULL,
    "user_id" INTEGER NOT NULL,
    "card_id" VARCHAR(50) NOT NULL,
    "card_no" VARCHAR(20) NOT NULL,
    "cvv" VARCHAR(4) NOT NULL,
    "exp_date" DATE NOT NULL,
    "balance" DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    "currency" VARCHAR(3) NOT NULL DEFAULT 'USD',
    "status" "public"."CardStatus" NOT NULL DEFAULT 'active',
    "cardholder_name" VARCHAR(100) NOT NULL,
    "cardholder_username" VARCHAR(50) NOT NULL,
    "cardholder_email" VARCHAR(100),
    "created_by" INTEGER NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "remark" TEXT,

    CONSTRAINT "virtual_cards_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."transactions" (
    "id" SERIAL NOT NULL,
    "card_id" INTEGER NOT NULL,
    "txn_id" VARCHAR(100) NOT NULL,
    "txn_type" "public"."TransactionType" NOT NULL,
    "amount" DECIMAL(10,2) NOT NULL,
    "currency" VARCHAR(3) NOT NULL,
    "status" "public"."TransactionStatus" NOT NULL,
    "merchant" VARCHAR(200),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "transactions_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "users_username_key" ON "public"."users"("username");

-- CreateIndex
CREATE UNIQUE INDEX "users_email_key" ON "public"."users"("email");

-- CreateIndex
CREATE INDEX "users_username_idx" ON "public"."users"("username");

-- CreateIndex
CREATE INDEX "users_email_idx" ON "public"."users"("email");

-- CreateIndex
CREATE INDEX "users_parent_id_idx" ON "public"."users"("parent_id");

-- CreateIndex
CREATE INDEX "users_role_idx" ON "public"."users"("role");

-- CreateIndex
CREATE INDEX "users_status_idx" ON "public"."users"("status");

-- CreateIndex
CREATE INDEX "user_balance_logs_user_id_idx" ON "public"."user_balance_logs"("user_id");

-- CreateIndex
CREATE INDEX "user_balance_logs_type_idx" ON "public"."user_balance_logs"("type");

-- CreateIndex
CREATE INDEX "user_balance_logs_operated_by_idx" ON "public"."user_balance_logs"("operated_by");

-- CreateIndex
CREATE INDEX "user_balance_logs_created_at_idx" ON "public"."user_balance_logs"("created_at");

-- CreateIndex
CREATE UNIQUE INDEX "virtual_cards_card_id_key" ON "public"."virtual_cards"("card_id");

-- CreateIndex
CREATE INDEX "virtual_cards_user_id_idx" ON "public"."virtual_cards"("user_id");

-- CreateIndex
CREATE INDEX "virtual_cards_card_id_idx" ON "public"."virtual_cards"("card_id");

-- CreateIndex
CREATE INDEX "virtual_cards_cardholder_username_idx" ON "public"."virtual_cards"("cardholder_username");

-- CreateIndex
CREATE INDEX "virtual_cards_status_idx" ON "public"."virtual_cards"("status");

-- CreateIndex
CREATE INDEX "virtual_cards_created_by_idx" ON "public"."virtual_cards"("created_by");

-- CreateIndex
CREATE INDEX "transactions_card_id_idx" ON "public"."transactions"("card_id");

-- CreateIndex
CREATE INDEX "transactions_txn_id_idx" ON "public"."transactions"("txn_id");

-- CreateIndex
CREATE INDEX "transactions_txn_type_idx" ON "public"."transactions"("txn_type");

-- CreateIndex
CREATE INDEX "transactions_status_idx" ON "public"."transactions"("status");

-- CreateIndex
CREATE INDEX "transactions_created_at_idx" ON "public"."transactions"("created_at");

-- AddForeignKey
ALTER TABLE "public"."users" ADD CONSTRAINT "users_parent_id_fkey" FOREIGN KEY ("parent_id") REFERENCES "public"."users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."user_balance_logs" ADD CONSTRAINT "user_balance_logs_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."user_balance_logs" ADD CONSTRAINT "user_balance_logs_operated_by_fkey" FOREIGN KEY ("operated_by") REFERENCES "public"."users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."user_balance_logs" ADD CONSTRAINT "user_balance_logs_related_card_id_fkey" FOREIGN KEY ("related_card_id") REFERENCES "public"."virtual_cards"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."user_balance_logs" ADD CONSTRAINT "user_balance_logs_related_user_id_fkey" FOREIGN KEY ("related_user_id") REFERENCES "public"."users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."virtual_cards" ADD CONSTRAINT "virtual_cards_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."virtual_cards" ADD CONSTRAINT "virtual_cards_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."transactions" ADD CONSTRAINT "transactions_card_id_fkey" FOREIGN KEY ("card_id") REFERENCES "public"."virtual_cards"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

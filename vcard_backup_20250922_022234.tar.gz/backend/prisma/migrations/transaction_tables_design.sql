-- 虚拟卡交易表设计
-- 支持授权(Auth)和结算(Settle)流程

-- 交易记录表 (统一处理Auth和Settle)
CREATE TABLE card_transactions (
    id SERIAL PRIMARY KEY,
    
    -- 关联信息
    card_id VARCHAR(50) NOT NULL COMMENT '卡商卡片ID',
    user_id INTEGER NOT NULL COMMENT '卡片所属用户ID',
    username VARCHAR(50) NOT NULL COMMENT '卡片所属用户名',
    
    -- 交易基本信息
    txn_id VARCHAR(100) NOT NULL COMMENT '交易ID',
    auth_txn_id VARCHAR(100) COMMENT '关联的授权交易ID(结算时使用)',
    origin_txn_id VARCHAR(100) DEFAULT '0' COMMENT '原始交易ID(授权撤销时使用)',
    
    -- 交易类型和状态
    txn_type VARCHAR(10) NOT NULL COMMENT '交易类型: A=授权, D=授权撤销, C=消费结算, R=退款结算',
    txn_status VARCHAR(10) NOT NULL COMMENT '交易状态: 0=失败, 1=成功',
    biz_type VARCHAR(10) COMMENT '业务类型: 01=提现, 30=查询余额, 99=消费',
    
    -- 金额信息
    txn_amount DECIMAL(15,4) NOT NULL COMMENT '交易金额',
    txn_currency VARCHAR(3) NOT NULL COMMENT '交易币种',
    bill_amount DECIMAL(15,4) NOT NULL COMMENT '账单金额',
    bill_currency VARCHAR(3) NOT NULL COMMENT '账单币种',
    final_amount DECIMAL(15,4) NOT NULL COMMENT '最终金额(授权时=账单金额,结算后=结算账单金额)',
    
    -- 商户信息
    merchant_name VARCHAR(500) COMMENT '商户名称',
    merchant_country VARCHAR(10) COMMENT '商户国家',
    mcc VARCHAR(100) COMMENT '商家业务类型',
    auth_code VARCHAR(50) COMMENT '授权码',
    decline_reason VARCHAR(500) COMMENT '拒绝原因',
    
    -- 时间信息
    txn_time TIMESTAMP NOT NULL COMMENT '交易时间',
    clearing_date DATE COMMENT '清算日期(结算时有值)',
    
    -- 回调原始数据
    raw_callback_data JSONB COMMENT '卡商回调原始数据',
    
    -- 处理状态
    is_auth_only BOOLEAN DEFAULT TRUE COMMENT '是否仅有授权(未结算)',
    is_settled BOOLEAN DEFAULT FALSE COMMENT '是否已结算',
    settle_txn_id VARCHAR(100) COMMENT '对应的结算交易ID',
    
    -- 其他信息
    sub_id VARCHAR(100) COMMENT '子账户ID',
    trade_note VARCHAR(500) COMMENT '交易备注',
    force_post BOOLEAN DEFAULT FALSE,
    pre_auth BOOLEAN DEFAULT FALSE,
    
    -- 系统字段
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- 索引
    CONSTRAINT card_transactions_pkey PRIMARY KEY (id),
    CONSTRAINT unique_txn_id UNIQUE (txn_id),
    
    -- 外键约束
    CONSTRAINT fk_card_transactions_user_id FOREIGN KEY (user_id) REFERENCES users(id),
    
    -- 索引优化
    INDEX idx_card_id (card_id),
    INDEX idx_user_id (user_id),
    INDEX idx_username (username),
    INDEX idx_txn_id (txn_id),
    INDEX idx_auth_txn_id (auth_txn_id),
    INDEX idx_txn_type (txn_type),
    INDEX idx_txn_status (txn_status),
    INDEX idx_is_auth_only (is_auth_only),
    INDEX idx_is_settled (is_settled),
    INDEX idx_txn_time (txn_time),
    INDEX idx_clearing_date (clearing_date),
    INDEX idx_created_at (created_at)
);

-- 添加注释
COMMENT ON TABLE card_transactions IS '虚拟卡交易记录表,统一处理授权和结算流程';

-- 交易汇总统计表 (可选,用于快速查询)
CREATE TABLE card_transaction_summary (
    id SERIAL PRIMARY KEY,
    card_id VARCHAR(50) NOT NULL,
    user_id INTEGER NOT NULL,
    username VARCHAR(50) NOT NULL,
    
    -- 统计信息
    total_auth_count INTEGER DEFAULT 0 COMMENT '总授权次数',
    total_auth_amount DECIMAL(15,4) DEFAULT 0 COMMENT '总授权金额',
    total_settle_count INTEGER DEFAULT 0 COMMENT '总结算次数', 
    total_settle_amount DECIMAL(15,4) DEFAULT 0 COMMENT '总结算金额',
    pending_auth_count INTEGER DEFAULT 0 COMMENT '待结算授权数',
    pending_auth_amount DECIMAL(15,4) DEFAULT 0 COMMENT '待结算授权金额',
    
    -- 时间信息
    first_transaction_at TIMESTAMP COMMENT '首次交易时间',
    last_transaction_at TIMESTAMP COMMENT '最后交易时间',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT card_transaction_summary_pkey PRIMARY KEY (id),
    CONSTRAINT unique_card_summary UNIQUE (card_id),
    CONSTRAINT fk_summary_user_id FOREIGN KEY (user_id) REFERENCES users(id),
    
    INDEX idx_summary_card_id (card_id),
    INDEX idx_summary_user_id (user_id),
    INDEX idx_summary_username (username)
);

COMMENT ON TABLE card_transaction_summary IS '卡片交易汇总统计表,用于快速查询交易概况';

-- AlterTable
ALTER TABLE "card_transactions" ADD COLUMN     "auth_time" TIMESTAMP(3),
ADD COLUMN     "settle_time" TIMESTAMP(3);

-- CreateIndex
CREATE INDEX "card_transactions_auth_time_idx" ON "card_transactions"("auth_time");

-- CreateIndex
CREATE INDEX "card_transactions_settle_time_idx" ON "card_transactions"("settle_time");

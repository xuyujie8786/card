import React, { useEffect, useState } from 'react';
import { Card, Row, Col, Statistic, Spin, message, Typography } from 'antd';
import { 
  DollarOutlined, 
  CreditCardOutlined, 
  BankOutlined, 
  WalletOutlined,
  ArrowUpOutlined,
  ArrowDownOutlined
} from '@ant-design/icons';
import { PageContainer } from '@ant-design/pro-components';
import { getDashboardData } from '@/services/dashboard';

const { Title } = Typography;

interface DashboardData {
  totalRecharge: number;
  totalConsumption: number;
  cardLocked: number;
  availableAmount: number;
}

const Dashboard: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const response = await getDashboardData();
      if (response.success) {
        setDashboardData(response.data);
      } else {
        message.error('获取仪表盘数据失败');
      }
    } catch (error) {
      console.error('获取仪表盘数据失败:', error);
      message.error('获取仪表盘数据失败');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  if (loading) {
    return (
      <PageContainer>
        <div style={{ textAlign: 'center', padding: '50px' }}>
          <Spin size="large" />
        </div>
      </PageContainer>
    );
  }

  if (!dashboardData) {
    return (
      <PageContainer>
        <div style={{ textAlign: 'center', padding: '50px' }}>
          <Title level={4}>暂无数据</Title>
        </div>
      </PageContainer>
    );
  }

  return (
    <PageContainer
      header={{
        title: '仪表盘',
        subTitle: '查看您的账户概况',
      }}
    >
      <Row gutter={[16, 16]}>
        <Col xs={24} sm={12} md={6}>
          <Card>
            <Statistic
              title="总充值"
              value={dashboardData.totalRecharge}
              precision={2}
              valueStyle={{ color: '#3f8600' }}
              prefix={<ArrowUpOutlined />}
              suffix="USD"
            />
          </Card>
        </Col>
        
        <Col xs={24} sm={12} md={6}>
          <Card>
            <Statistic
              title="总消费"
              value={dashboardData.totalConsumption}
              precision={2}
              valueStyle={{ color: '#cf1322' }}
              prefix={<ArrowDownOutlined />}
              suffix="USD"
            />
          </Card>
        </Col>
        
        <Col xs={24} sm={12} md={6}>
          <Card>
            <Statistic
              title="卡内锁定"
              value={dashboardData.cardLocked}
              precision={2}
              valueStyle={{ color: '#faad14' }}
              prefix={<CreditCardOutlined />}
              suffix="USD"
            />
          </Card>
        </Col>
        
        <Col xs={24} sm={12} md={6}>
          <Card>
            <Statistic
              title="可用余额"
              value={dashboardData.availableAmount}
              precision={2}
              valueStyle={{ 
                color: dashboardData.availableAmount >= 0 ? '#3f8600' : '#cf1322' 
              }}
              prefix={<WalletOutlined />}
              suffix="USD"
            />
          </Card>
        </Col>
      </Row>

      <Row gutter={[16, 16]} style={{ marginTop: 24 }}>
        <Col xs={24} lg={12}>
          <Card 
            title="账户概况" 
            extra={
              <DollarOutlined style={{ color: '#1890ff' }} />
            }
          >
            <div style={{ padding: '16px 0' }}>
              <Row>
                <Col span={12}>
                  <Statistic
                    title="净资产"
                    value={dashboardData.totalRecharge - dashboardData.totalConsumption}
                    precision={2}
                    valueStyle={{ 
                      color: (dashboardData.totalRecharge - dashboardData.totalConsumption) >= 0 ? '#3f8600' : '#cf1322'
                    }}
                    suffix="USD"
                  />
                </Col>
                <Col span={12}>
                  <Statistic
                    title="消费率"
                    value={dashboardData.totalRecharge > 0 ? (dashboardData.totalConsumption / dashboardData.totalRecharge * 100) : 0}
                    precision={1}
                    suffix="%"
                    valueStyle={{ color: '#1890ff' }}
                  />
                </Col>
              </Row>
            </div>
          </Card>
        </Col>

        <Col xs={24} lg={12}>
          <Card 
            title="资金状况" 
            extra={
              <BankOutlined style={{ color: '#52c41a' }} />
            }
          >
            <div style={{ padding: '16px 0' }}>
              <Row>
                <Col span={12}>
                  <Statistic
                    title="已锁定资金"
                    value={dashboardData.cardLocked}
                    precision={2}
                    suffix="USD"
                    valueStyle={{ color: '#faad14' }}
                  />
                </Col>
                <Col span={12}>
                  <Statistic
                    title="可用资金"
                    value={dashboardData.availableAmount}
                    precision={2}
                    suffix="USD"
                    valueStyle={{ 
                      color: dashboardData.availableAmount >= 0 ? '#52c41a' : '#f5222d'
                    }}
                  />
                </Col>
              </Row>
            </div>
          </Card>
        </Col>
      </Row>
    </PageContainer>
  );
};

export default Dashboard;

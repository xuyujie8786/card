/*
  Warnings:

  - You are about to drop the `user_balance_logs` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "user_balance_logs" DROP CONSTRAINT "user_balance_logs_operated_by_fkey";

-- DropForeignKey
ALTER TABLE "user_balance_logs" DROP CONSTRAINT "user_balance_logs_related_card_id_fkey";

-- DropForeignKey
ALTER TABLE "user_balance_logs" DROP CONSTRAINT "user_balance_logs_related_user_id_fkey";

-- DropForeignKey
ALTER TABLE "user_balance_logs" DROP CONSTRAINT "user_balance_logs_user_id_fkey";

-- DropTable
DROP TABLE "user_balance_logs";

-- DropEnum
DROP TYPE "BalanceLogType";

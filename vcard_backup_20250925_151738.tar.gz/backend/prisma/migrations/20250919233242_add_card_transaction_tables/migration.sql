/*
  Warnings:

  - You are about to drop the `transactions` table. If the table is not empty, all the data it contains will be lost.

*/
-- CreateEnum
CREATE TYPE "CardTxnType" AS ENUM ('A', 'D', 'C', 'R');

-- DropForeignKey
ALTER TABLE "transactions" DROP CONSTRAINT "transactions_card_id_fkey";

-- DropTable
DROP TABLE "transactions";

-- DropEnum
DROP TYPE "TransactionStatus";

-- DropEnum
DROP TYPE "TransactionType";

-- CreateTable
CREATE TABLE "card_transactions" (
    "id" SERIAL NOT NULL,
    "card_id" VARCHAR(50) NOT NULL,
    "user_id" INTEGER NOT NULL,
    "username" VARCHAR(50) NOT NULL,
    "txn_id" VARCHAR(100) NOT NULL,
    "auth_txn_id" VARCHAR(100),
    "origin_txn_id" VARCHAR(100) NOT NULL DEFAULT '0',
    "txn_type" "CardTxnType" NOT NULL,
    "txn_status" VARCHAR(10) NOT NULL,
    "biz_type" VARCHAR(10),
    "txn_amount" DECIMAL(15,4) NOT NULL,
    "txn_currency" VARCHAR(3) NOT NULL,
    "bill_amount" DECIMAL(15,4) NOT NULL,
    "bill_currency" VARCHAR(3) NOT NULL,
    "final_amount" DECIMAL(15,4) NOT NULL,
    "merchant_name" VARCHAR(500),
    "merchant_country" VARCHAR(10),
    "mcc" VARCHAR(100),
    "auth_code" VARCHAR(50),
    "decline_reason" VARCHAR(500),
    "txn_time" TIMESTAMP(3) NOT NULL,
    "clearing_date" DATE,
    "raw_callback_data" JSONB,
    "is_auth_only" BOOLEAN NOT NULL DEFAULT true,
    "is_settled" BOOLEAN NOT NULL DEFAULT false,
    "settle_txn_id" VARCHAR(100),
    "sub_id" VARCHAR(100),
    "trade_note" VARCHAR(500),
    "force_post" BOOLEAN NOT NULL DEFAULT false,
    "pre_auth" BOOLEAN NOT NULL DEFAULT false,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "card_transactions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "card_transaction_summary" (
    "id" SERIAL NOT NULL,
    "card_id" VARCHAR(50) NOT NULL,
    "user_id" INTEGER NOT NULL,
    "username" VARCHAR(50) NOT NULL,
    "total_auth_count" INTEGER NOT NULL DEFAULT 0,
    "total_auth_amount" DECIMAL(15,4) NOT NULL DEFAULT 0,
    "total_settle_count" INTEGER NOT NULL DEFAULT 0,
    "total_settle_amount" DECIMAL(15,4) NOT NULL DEFAULT 0,
    "pending_auth_count" INTEGER NOT NULL DEFAULT 0,
    "pending_auth_amount" DECIMAL(15,4) NOT NULL DEFAULT 0,
    "first_transaction_at" TIMESTAMP(3),
    "last_transaction_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "card_transaction_summary_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "card_transactions_txn_id_key" ON "card_transactions"("txn_id");

-- CreateIndex
CREATE INDEX "card_transactions_card_id_idx" ON "card_transactions"("card_id");

-- CreateIndex
CREATE INDEX "card_transactions_user_id_idx" ON "card_transactions"("user_id");

-- CreateIndex
CREATE INDEX "card_transactions_username_idx" ON "card_transactions"("username");

-- CreateIndex
CREATE INDEX "card_transactions_txn_id_idx" ON "card_transactions"("txn_id");

-- CreateIndex
CREATE INDEX "card_transactions_auth_txn_id_idx" ON "card_transactions"("auth_txn_id");

-- CreateIndex
CREATE INDEX "card_transactions_txn_type_idx" ON "card_transactions"("txn_type");

-- CreateIndex
CREATE INDEX "card_transactions_txn_status_idx" ON "card_transactions"("txn_status");

-- CreateIndex
CREATE INDEX "card_transactions_is_auth_only_idx" ON "card_transactions"("is_auth_only");

-- CreateIndex
CREATE INDEX "card_transactions_is_settled_idx" ON "card_transactions"("is_settled");

-- CreateIndex
CREATE INDEX "card_transactions_txn_time_idx" ON "card_transactions"("txn_time");

-- CreateIndex
CREATE INDEX "card_transactions_clearing_date_idx" ON "card_transactions"("clearing_date");

-- CreateIndex
CREATE INDEX "card_transactions_created_at_idx" ON "card_transactions"("created_at");

-- CreateIndex
CREATE UNIQUE INDEX "card_transaction_summary_card_id_key" ON "card_transaction_summary"("card_id");

-- CreateIndex
CREATE INDEX "card_transaction_summary_card_id_idx" ON "card_transaction_summary"("card_id");

-- CreateIndex
CREATE INDEX "card_transaction_summary_user_id_idx" ON "card_transaction_summary"("user_id");

-- CreateIndex
CREATE INDEX "card_transaction_summary_username_idx" ON "card_transaction_summary"("username");

-- AddForeignKey
ALTER TABLE "card_transactions" ADD CONSTRAINT "card_transactions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "card_transaction_summary" ADD CONSTRAINT "card_transaction_summary_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

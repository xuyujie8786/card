-- Add WITHDRAWAL support to CardTxnType enum
ALTER TYPE "CardTxnType" ADD VALUE IF NOT EXISTS 'W';

-- Add withdrawal-related fields to card_transactions table
ALTER TABLE "card_transactions" ADD COLUMN "related_txn_id" VARCHAR(100);
ALTER TABLE "card_transactions" ADD COLUMN "withdrawal_status" VARCHAR(20);

-- Add indexes for new fields
CREATE INDEX IF NOT EXISTS "card_transactions_related_txn_id_idx" ON "card_transactions"("related_txn_id");
CREATE INDEX IF NOT EXISTS "card_transactions_withdrawal_status_idx" ON "card_transactions"("withdrawal_status");
